import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '100kb' }));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'FitMate AI' }));

app.post('/api/coach', async (req, res) => {
  const { sets = [], summary = '' } = req.body ?? {};
  if (!Array.isArray(sets) || sets.length > 300) return res.status(400).json({ error: 'Invalid sets payload' });
  if (!process.env.AI_API_KEY || process.env.AI_API_KEY === 'replace_me') {
    return res.status(503).json({ error: 'AI provider is not configured' });
  }
  try {
    const base = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
    const upstream = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.AI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: process.env.AI_MODEL || 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'أنت مدرب لياقة مسؤول. حلل سجل التمرين بالعربية المصرية بإيجاز. لا تشخص إصابات ولا تقترح أوزاناً خطرة. وضح أن اقتراحاتك عامة وليست بديلاً عن مدرب مؤهل.' },
          { role: 'user', content: JSON.stringify({ summary, sets }) }
        ],
        temperature: 0.4
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: 'AI provider error' });
    const insight = data.choices?.[0]?.message?.content || summary;
    res.json({ insight });
  } catch {
    res.status(502).json({ error: 'Could not reach AI provider' });
  }
});

const port = Number(process.env.PORT || 8787);
app.listen(port, () => console.log(`FitMate backend listening on ${port}`));
