# FitMate AI — Android starter

نسخة أولية لتطبيق جيم Android باستخدام Flutter. تحتوي على:
- تسجيل التمرين والوقت والمجموعات والوزن والعدات.
- إدخال صوتي عربي/إنجليزي (حسب دعم محرك تحويل الكلام إلى نص في الهاتف).
- كتالوج تمارين مبدئي بصيغة JSON.
- حفظ محلي باستخدام SQLite.
- تسجيل اسم الموسيقى/البودكاست ومدته داخل جلسة التمرين.
- تحليل أولي محلي، مع Backend اختياري لتوصيل AI بأمان.

> هذه حزمة ملفات المصدر وليست APK جاهزاً. يلزم تثبيت Flutter وAndroid Studio ثم إنشاء هيكل Android الأصلي بالأمر الموضح أدناه.

## 1) إنشاء مشروع Flutter

```bash
flutter create --org com.fitmate --project-name fitmate_ai fitmate_ai
cd fitmate_ai
```

انسخ مجلدات `lib/` و`assets/` وملف `pubspec.yaml` من هذه الحزمة إلى المشروع الذي أنشأته، مع استبدال الملفات عند الطلب.

ثم:

```bash
flutter pub get
flutter run
```

## 2) متطلبات Android للصوت

افتح `android/app/src/main/AndroidManifest.xml` وأضف قبل `<application>`:

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.INTERNET"/>
```

داخل `<application>` يمكن إضافة (إذا احتاج محرك التعرف على الكلام):

```xml
<queries>
    <intent>
        <action android:name="android.speech.RecognitionService" />
    </intent>
</queries>
```

قد تختلف إمكانية التعرف على الكلام حسب إصدار Android، اللغة المثبتة، وخدمات Google المتاحة. اختبر العربية والإنجليزية على جهازك.

## 3) توصيل AI اختيارياً

يوجد Backend منفصل في `backend/`. لا تضع مفتاح API داخل تطبيق Android أو GitHub.

```bash
cd backend
cp .env.example .env
# ضع المفتاح داخل .env محلياً فقط
npm install
npm start
```

اضبط `FITMATE_AI_URL` في `lib/services/ai_service.dart` على عنوان خادمك. عند النشر استخدم HTTPS. لا ترفع ملف `.env`.

الخادم يستخدم واجهة OpenAI-compatible عبر متغيرات البيئة. عدّل `AI_BASE_URL` و`AI_MODEL` حسب مزودك. إذا لم يتم إعداد الخادم، التطبيق يعرض تحليلاً محلياً بسيطاً بدلاً منه.

## 4) ما الموجود وما الذي يحتاج استكمالاً؟

- البيانات الحالية كتالوج بداية عام، وليست برنامجاً طبياً أو خطة تدريب شخصية.
- التطبيق يحفظ سجلات التمرين محلياً على الجهاز؛ لا يوجد حساب أو مزامنة سحابية بعد.
- الصوت يسجل النص الذي تم التعرف عليه، ثم يحاول استخراج الوزن والعدات. راجع النتيجة قبل الحفظ.
- تشغيل الموسيقى من Spotify/YouTube Music غير مدمج؛ النسخة الحالية تسجل اسم المحتوى ومدته فقط. الربط المباشر يحتاج OAuth وموافقات API من مزود الخدمة.
- قبل النشر على Google Play: أضف سياسة خصوصية، اختبارات، أيقونة، اسم الحزمة النهائي، وراجع أذونات الصوت وسياسات المتجر.

## 5) رفعه على GitHub

أنشئ Repository جديداً، ثم من مجلد المشروع:

```bash
git init
git add .
git commit -m "Initial FitMate AI Android app"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

لا ترفع `backend/.env` أو أي مفاتيح سرية.
