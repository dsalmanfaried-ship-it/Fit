import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseService {
  DatabaseService._();
  static final instance = DatabaseService._();
  Database? _db;
  Future<void> init() async {
    final path = join(await getDatabasesPath(), 'fitmate_ai.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''CREATE TABLE sessions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        started_at TEXT NOT NULL,
        ended_at TEXT,
        duration_seconds INTEGER DEFAULT 0,
        audio_name TEXT,
        audio_minutes INTEGER DEFAULT 0
      )''');
      await db.execute('''CREATE TABLE workout_sets(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        exercise_id TEXT NOT NULL,
        exercise_name TEXT NOT NULL,
        weight REAL NOT NULL,
        reps INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(session_id) REFERENCES sessions(id)
      )''');
    });
    await _db!.execute('PRAGMA foreign_keys = ON');
  }
  Future<int> startSession() => _db!.insert('sessions', {'started_at': DateTime.now().toIso8601String()});
  Future<void> addSet({required int sessionId, required String exerciseId, required String exerciseName, required double weight, required int reps}) async {
    await _db!.insert('workout_sets', {
      'session_id': sessionId, 'exercise_id': exerciseId, 'exercise_name': exerciseName,
      'weight': weight, 'reps': reps, 'created_at': DateTime.now().toIso8601String()
    });
  }
  Future<void> finishSession(int id, int seconds, String? audioName, int audioMinutes) async {
    await _db!.update('sessions', {'ended_at': DateTime.now().toIso8601String(), 'duration_seconds': seconds,
      'audio_name': audioName, 'audio_minutes': audioMinutes}, where: 'id = ?', whereArgs: [id]);
  }
  Future<List<Map<String, dynamic>>> sessions() => _db!.query('sessions', orderBy: 'started_at DESC');
  Future<List<Map<String, dynamic>>> setsForSession(int id) => _db!.query('workout_sets', where: 'session_id = ?', whereArgs: [id]);
}
