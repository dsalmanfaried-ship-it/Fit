import 'dart:convert';
import 'package:http/http.dart' as http;

/// Keep the AI key on your server. Never embed provider secrets in the Android app.
class AiService {
  static const String endpoint = String.fromEnvironment(
    'FITMATE_AI_URL',
    defaultValue: '',
  );

  Future<String> localInsight(List<Map<String, dynamic>> sets) async {
    if (sets.isEmpty) return 'لم يتم تسجيل مجموعات في هذه الجلسة. جرّب تسجيل أول مجموعة في المرة القادمة.';
    final totalReps = sets.fold<int>(0, (sum, s) => sum + (s['reps'] as int));
    final totalVolume = sets.fold<double>(0, (sum, s) => sum + ((s['weight'] as num).toDouble() * (s['reps'] as int)));
    final exerciseCount = sets.map((s) => s['exercise_id']).toSet().length;
    final base = 'سجلت ${sets.length} مجموعة، بإجمالي $totalReps عدة، وحجم تدريبي تقريبي ${totalVolume.toStringAsFixed(0)} كجم×عدة عبر $exerciseCount تمرين.';
    if (endpoint.isEmpty) return '$base\\nاستمر في تسجيل كل مجموعة. بعد عدة جلسات سنقدر نقارن الأوزان والعدات بشكل أفضل.';
    try {
      final response = await http.post(Uri.parse(endpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'sets': sets, 'summary': base}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['insight']?.toString() ?? base;
      }
    } catch (_) {}
    return '$base\\nتعذر الوصول إلى مدرب AI حالياً، لذلك ظهر التحليل المحلي.';
  }
}
