import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'services/database_service.dart';
import 'services/ai_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseService.instance.init();
  runApp(const FitMateApp());
}

class FitMateApp extends StatelessWidget {
  const FitMateApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'FitMate AI',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF16A085), brightness: Brightness.dark),
      scaffoldBackgroundColor: const Color(0xFF101716),
      useMaterial3: true,
      cardTheme: const CardThemeData(color: Color(0xFF1B2623)),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _tab = 0;
  Map<String, dynamic>? _active;
  List<Map<String, dynamic>> _history = [];
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final rows = await DatabaseService.instance.sessions();
    if (mounted) setState(() => _history = rows);
  }
  Future<void> _start() async {
    final id = await DatabaseService.instance.startSession();
    setState(() => _active = {'id': id, 'started_at': DateTime.now().toIso8601String()});
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => WorkoutPage(
      sessionId: id, onFinished: () { setState(() => _active = null); _load(); },
    )));
  }
  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      ProgressPage(history: _history),
      const AudioInfoPage(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('FITMATE AI'), actions: [
        IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'FitMate AI',
          applicationVersion: '0.1.0', children: const [Text('متتبع تمارين بالصوت مع سجل محلي وتحليل ذكي مبدئي.')]),
          icon: const Icon(Icons.info_outline))
      ]),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (v) => setState(() => _tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.insights), label: 'التقدم'),
          NavigationDestination(icon: Icon(Icons.headphones), label: 'الصوت'),
        ]),
    );
  }
  Widget _home() => RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(18), children: [
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF145A4A), Color(0xFF203A35)]),
      borderRadius: BorderRadius.circular(22)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('جاهز لتمرينك؟', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), const Text('سجّل مجموعاتك بصوتك وتابع تقدمك خطوة بخطوة.'),
        const SizedBox(height: 20),
        FilledButton.icon(onPressed: _start, icon: const Icon(Icons.play_arrow), label: const Text('ابدأ تمرين جديد')),
      ]),
    ),
    const SizedBox(height: 20),
    Row(children: [
      Expanded(child: _stat('جلسات مسجلة', '${_history.length}', Icons.fitness_center)),
      const SizedBox(width: 12),
      Expanded(child: _stat('آخر تمرين', _history.isEmpty ? '—' : DateFormat('MM/dd').format(DateTime.parse(_history.first['started_at'])), Icons.calendar_today)),
    ]),
    const SizedBox(height: 22),
    const Text('آخر الجلسات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    if (_history.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('لسه مفيش جلسات. ابدأ أول تمرين وسجّل أداءك.'))),
    ..._history.take(5).map((s) => Card(child: ListTile(
      leading: const CircleAvatar(child: Icon(Icons.bolt)),
      title: Text(DateFormat('EEEE d MMM', 'ar').format(DateTime.parse(s['started_at']))),
      subtitle: Text('المدة: ${s['duration_seconds'] ?? 0} ثانية'),
      trailing: const Icon(Icons.chevron_left),
    ))),
  ]));
  Widget _stat(String title, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: const Color(0xFF5ED6B4)), const SizedBox(height: 12),
      Text(value, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      Text(title, style: const TextStyle(color: Colors.white70)),
    ])));
}

class WorkoutPage extends StatefulWidget {
  final int sessionId;
  final VoidCallback onFinished;
  const WorkoutPage({super.key, required this.sessionId, required this.onFinished});
  @override
  State<WorkoutPage> createState() => _WorkoutPageState();
}
class _WorkoutPageState extends State<WorkoutPage> {
  final _speech = stt.SpeechToText();
  final _weight = TextEditingController();
  final _reps = TextEditingController(text: '10');
  final _rest = TextEditingController(text: '90');
  final _audioName = TextEditingController();
  final _audioMinutes = TextEditingController();
  List<Map<String, dynamic>> _exercises = [];
  String? _exerciseId;
  String _heard = '';
  String _locale = 'ar_EG';
  bool _listening = false;
  bool _paused = false;
  int _elapsed = 0;
  Timer? _timer;
  int _sets = 0;
  @override
  void initState() { super.initState(); _loadExercises(); _timer = Timer.periodic(const Duration(seconds: 1), (_) {
    if (!_paused && mounted) setState(() => _elapsed++);
  }); }
  Future<void> _loadExercises() async {
    final raw = await rootBundle.loadString('assets/exercises.json');
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    setState(() { _exercises = list; _exerciseId = list.first['id']; });
  }
  String get _exerciseName => _exercises.firstWhere((e) => e['id'] == _exerciseId, orElse: () => {'name_ar':'تمرين'})['name_ar'];
  Future<void> _listen() async {
    if (_listening) { await _speech.stop(); setState(() => _listening = false); return; }
    final available = await _speech.initialize(onStatus: (s) { if (s == 'notListening' && mounted) setState(() => _listening = false); },
      onError: (_) { if (mounted) setState(() => _listening = false); });
    if (!available) { _snack('التعرف على الصوت غير متاح على هذا الجهاز'); return; }
    setState(() => _listening = true);
    await _speech.listen(localeId: _locale, listenFor: const Duration(seconds: 25), pauseFor: const Duration(seconds: 3),
      onResult: (r) { setState(() => _heard = r.recognizedWords); _parseVoice(r.recognizedWords); });
  }
  void _parseVoice(String text) {
    final nums = RegExp(r'\d+(?:[.,]\d+)?').allMatches(text).map((m) => m.group(0)!.replaceAll(',', '.')).toList();
    if (nums.isNotEmpty) {
      // المتوقع: عدد العدات ثم الوزن؛ راجع القيم قبل الحفظ.
      _reps.text = nums[0].split('.').first;
      if (nums.length > 1) _weight.text = nums[1];
    }
  }
  Future<void> _saveSet() async {
    final w = double.tryParse(_weight.text.replaceAll(',', '.'));
    final r = int.tryParse(_reps.text);
    if (_exerciseId == null || w == null || w < 0 || r == null || r < 1) { _snack('اكتب وزن صحيح وعدات أكبر من صفر'); return; }
    await DatabaseService.instance.addSet(sessionId: widget.sessionId, exerciseId: _exerciseId!, exerciseName: _exerciseName, weight: w, reps: r);
    setState(() { _sets++; });
    _weight.clear();
    _snack('تم تسجيل المجموعة');
  }
  Future<void> _finish() async {
    _timer?.cancel(); await _speech.stop();
    final audio = _audioName.text.trim().isEmpty ? null : _audioName.text.trim();
    await DatabaseService.instance.finishSession(widget.sessionId, _elapsed, audio, int.tryParse(_audioMinutes.text) ?? 0);
    final sets = await DatabaseService.instance.setsForSession(widget.sessionId);
    final insight = await AiService().localInsight(sets);
    if (!mounted) return;
    await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('ملخص التمرين'),
      content: Text('المدة: ${_elapsed ~/ 60} دقيقة\\nالمجموعات المسجلة: $_sets\\n\\n$insight'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('تمام'))]));
    widget.onFinished(); if (mounted) Navigator.pop(context);
  }
  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  @override
  void dispose() { _timer?.cancel(); _speech.stop(); _weight.dispose(); _reps.dispose(); _rest.dispose(); _audioName.dispose(); _audioMinutes.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('جلسة التمرين'), leading: IconButton(icon: const Icon(Icons.close), onPressed: _finish)),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
        Text(_paused ? 'متوقف مؤقتاً' : 'وقت التمرين', style: const TextStyle(color: Colors.white70)),
        Text('${(_elapsed ~/ 3600).toString().padLeft(2,'0')}:${((_elapsed ~/ 60)%60).toString().padLeft(2,'0')}:${(_elapsed%60).toString().padLeft(2,'0')}',
          style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold)),
        Wrap(spacing: 10, children: [
          OutlinedButton.icon(onPressed: () => setState(() => _paused = !_paused), icon: Icon(_paused ? Icons.play_arrow : Icons.pause), label: Text(_paused ? 'استكمال' : 'إيقاف مؤقت')),
          TextButton(onPressed: () => setState(() => _elapsed = 0), child: const Text('إعادة العداد')),
        ])
      ]))),
      const SizedBox(height: 16),
      const Text('التمرين', style: TextStyle(fontWeight: FontWeight.bold)),
      DropdownButtonFormField<String>(value: _exerciseId, isExpanded: true, items: _exercises.map((e) => DropdownMenuItem(
        value: e['id'] as String, child: Text('${e['name_ar']} · ${e['name_en']}'))).toList(), onChanged: (v) => setState(() => _exerciseId = v)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: TextField(controller: _reps, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'العدات', border: OutlineInputBorder()))),
        const SizedBox(width: 10),
        Expanded(child: TextField(controller: _weight, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'الوزن (كجم)', border: OutlineInputBorder()))),
      ]),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: _locale, decoration: const InputDecoration(labelText: 'لغة التسجيل الصوتي'),
        items: const [DropdownMenuItem(value: 'ar_EG', child: Text('عربي مصري')), DropdownMenuItem(value: 'en_US', child: Text('English'))],
        onChanged: (v) => setState(() => _locale = v ?? 'ar_EG')),
      FilledButton.icon(onPressed: _listen, icon: Icon(_listening ? Icons.stop : Icons.mic),
        label: Text(_listening ? 'إيقاف التسجيل' : 'سجّل المجموعة بالصوت')),
      if (_heard.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text('سمعت: $_heard', style: const TextStyle(color: Colors.white70))),
      FilledButton(onPressed: _saveSet, child: Text('حفظ المجموعة ($_sets محفوظة)')),
      const Divider(height: 32),
      const Text('الموسيقى / البودكاست', style: TextStyle(fontWeight: FontWeight.bold)),
      TextField(controller: _audioName, decoration: const InputDecoration(labelText: 'اسم Playlist أو المحتوى', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      TextField(controller: _audioMinutes, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'مدة الاستماع بالدقائق', border: OutlineInputBorder())),
      const SizedBox(height: 24),
      FilledButton.icon(onPressed: _finish, icon: const Icon(Icons.flag), label: const Text('إنهاء التمرين')),
    ]),
  );
}

class ProgressPage extends StatelessWidget {
  final List<Map<String, dynamic>> history;
  const ProgressPage({super.key, required this.history});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('تقدمك', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('إجمالي الجلسات', style: TextStyle(color: Colors.white70)),
      Text('${history.length}', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
      const Text('كل جلسة جديدة تُضاف إلى سجلك المحلي.'),
    ]))),
    const Text('ملاحظة: رسوم تطور الأوزان وتحليل العضلات ستضاف في المرحلة التالية بعد تجميع سجل كافٍ.', style: TextStyle(color: Colors.white70)),
  ]);
}

class AudioInfoPage extends StatelessWidget {
  const AudioInfoPage({super.key});
  @override
  Widget build(BuildContext context) => const Padding(padding: EdgeInsets.all(20), child: Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('الصوت أثناء التمرين', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      SizedBox(height: 12),
      Text('في النسخة الحالية يمكنك حفظ اسم قائمة التشغيل أو البودكاست ومدة الاستماع مع جلسة التمرين.'),
      SizedBox(height: 10),
      Text('تشغيل Spotify أو YouTube Music والتحكم فيهما مباشرة يحتاج ربطاً رسمياً بحسابك وموافقات API من كل خدمة.'),
    ]));
}
